package login;

public class BoardDTO {
private int num;
private String subject;
private String content;
private int hit;
private String ip;
private String reg_date;
private String mod_date;
}
