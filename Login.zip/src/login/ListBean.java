package login;
import java.util.Date;
import java.text.*;
public class ListBean{
	  
	  
	  private String productName;
		private int productPrice;
		private int productQuantity;        
	  private int i;
	  private int total;
	  private String id;
	  String date1;
	  String locate;
	  public String getDate(){
		  
		    return date1;
	  }
	  public String getLocate(){
		  return locate;
	  }
	  public void setLocate(String locate){
		  this.locate = locate;
	  }
	 public String getId(){
		 return id;
	 }
	 public void setId(String id){
		 this.id = id;
	 }
	  public void setDate(String date1){
		  this.date1 = date1;
	  }
	  public void setProductName(String productName){
			this.productName = productName;
		}
		public void setProductPrice(int productPrice){
			this.productPrice = productPrice;
		}
		public void setProductQuantity(int productQuantity){
			this.productQuantity = productQuantity;
		}
		
		public String getProductName(){
			return productName;
		}
		public int getProductPrice(){
			return productPrice;
		}
		public int getProductQuantity(){
			return productQuantity;
		}	
		public int getI(){
			return i;
		}
		public void setI(int i){
			this.i = i;
		}
	 }