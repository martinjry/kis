package login;

public class MemberDto {
	  private String membership;        
	  private String id;
	  public void setMembership(String membership){
			this.membership = membership;
			System.out.println(membership+1);
		}
		public String getMembership(){
			return membership;
		}
		 public void setId(String id){
				this.id = id;
			}
			public String getId(){
				return id;
			}		

}
