package login;

public class BuyDto {

}
