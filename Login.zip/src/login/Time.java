package login;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
public class Time {
	private String id;
	private String sangpum;
	private int price;
	private SimpleDateFormat time;
	private String purpose;
	private Connection conn= null;
	private Statement stmt = null;
	private ResultSet rs = null;
	Time t = new Time();
	public void Time(){
		
	}
	public void Time(String id,String sangpum,int price,SimpleDateFormat time,String purpose){
		this.id = id;
		this.sangpum = sangpum;
		this.price = price;
		this.time = time;
		this.purpose = purpose;
		
	}
	public String getId(){
		return id;
	}
	public String getSangpum(){
		return sangpum;
	}
	public int getPrice(){
		return price;
	}
	public SimpleDateFormat getTime(){
		return time;
	}
	public String getPurpose(){
		return purpose;
	}
	public void setId(String id){
		this.id=id;
	}
	public void setSangpum(String sangpum){
		this.sangpum = sangpum;
	}
	public void setPrice(int price){
		this.price= price;
	}
	public void setTime(SimpleDateFormat time){
		this.time = time;
	}
	public void setPurpose(String purpose){
		this.purpose=purpose;
	}
	public void sangpum1Check(){
		 try{
		 //����̹� ����
		 Class.forName("com.mysql.jdbc.Driver");
		 //jspdb�� DB�� // mysql->  user�� root  ��й�ȣ�� 1234
		 conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/member","root","");
		 
		 if(conn==null)
			 throw new Exception("�����ͺ��̽� ���� ����");
		 
		 //����� ���¸� stmt�� 
		 stmt=conn.createStatement();
		stmt.executeUpdate("insert into time values('"+t.getId()+"','"+t.getSangpum()+"',"+t.getPrice()+",'"+t.getTime()+"','"+t.getPurpose()+"');");
		 
		 
		 
	 } catch (Exception e) {
		e.printStackTrace();
	 }finally{
			
			try{stmt.close();}catch(SQLException s){}
			
			try{conn.close();}catch(SQLException s){}
		}
}



public static void main(String args[]){
	Calendar cal = Calendar.getInstance();
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	String str = format.format(cal.getTime());
	int str1 = cal.YEAR;
	int str2 = cal.MONTH+1;
	int str3 = cal.DATE
			;
	System.out.println(str);
	System.out.println(str1);
	System.out.println(str2);System.out.println(str3);
	
	
}
}
