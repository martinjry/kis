function printDate()
{
var time = new Date();
document.write("현재 시간:"+time);
}